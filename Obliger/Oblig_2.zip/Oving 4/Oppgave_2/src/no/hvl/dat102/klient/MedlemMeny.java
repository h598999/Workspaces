package no.hvl.dat102.klient;

public class MedlemMeny {
	
	
	
}
