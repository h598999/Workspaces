package no.hvl.dat102.hanoi;

public class SpillTaarnHanoi {

    public static void main(String[] args){    
    	Taarn taarn = new Taarn(4);
        taarn.spill();
   }

}
