package no.hvl.dat102.labyrint;

public class Main {

	public static void main(String[] args) {
		Labyrint labyrint = new Labyrint();
		System.out.println(labyrint);
        
		
	}

}
