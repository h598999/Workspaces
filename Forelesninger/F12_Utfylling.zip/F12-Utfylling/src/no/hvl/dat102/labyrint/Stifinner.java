package no.hvl.dat102.labyrint;

public class Stifinner {
	private Labyrint labyrint;
	
	public Stifinner(Labyrint labyrint) {
		this.labyrint = labyrint;
	}
	
	public boolean finnSti() { // Parameterliste
		boolean ferdig = false;
		
		// basis?
		
		// Rekursive kall
		
		return ferdig;
	}
}


