package no.hvl.dat102.stiar;

public class Stiar {
	
	static int antallStiar() {  // parameterliste?
		return 0;
	}

	public static void main(String[] args) {
		int rekker = 4;
		int kolonner = 3;
		
		// antal stiar fr� (1,1) til (4,3)
		System.out.println();   

	}

}
